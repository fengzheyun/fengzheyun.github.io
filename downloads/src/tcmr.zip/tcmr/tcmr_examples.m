matlabpool(7);
%% Loding in data
dataset = 'iaprtc12';
x_train_file = sprintf('%s/%s_train_DenseSift.hvecs', dataset, dataset);
x_test_file = sprintf('%s/%s_test_DenseSift.hvecs', dataset, dataset);
y_train_file = sprintf('%s/%s_train_annot.hvecs', dataset, dataset);
y_test_file = sprintf('%s/%s_test_annot.hvecs', dataset, dataset);
X_test = single(vec_read(x_test_file));
X_train = single(vec_read(x_train_file));
Y_test = single(vec_read(y_test_file));
Y_train = single(vec_read(y_train_file));
X = [X_train;X_test];
Y = [Y_train;Y_test];
index = (sum(Y,2)==0)|(sum(X,2) == 0);
X(index,:) = [];
Y(index,:) = [];
clear x_train_file x_test_file y_train_file y_test_file index X_train Y_train X_test Y_test;

num_tag = 4;%set value of m_*: The number of observed tags for each image
index = sum(Y,2)<=num_tag;% | sum(Y,2)>40; % remove documents whose words less than 3
Y(index,:) = [];
X(index,:) = [];

%% parameters setting
%load('K_iap.mat');
K_train = pdist2(X,X,'chisq');%pre-estimate the pairwise distance and the Laplacian graph
avg_dist = sum(sum(triu(K_train,1),2),1)./(size(X,1)*(size(X,1)-1)/2);
kc1 = ceil(0.001*size(Y,1)); %chi: mir:250 esp 9; iap:50

kc2 = 40;
runs = 10;% number of running iterations => help compute mean and deviation
max_rank = 10; % number of top tags considered as assigned tags in evaluation
gamma = 1.02; % parameter in solving the objective function

%% Visual feature: estimate the Laplacian graph
kc = max(kc1,kc2);
[D, N] = top(K_train, kc);
D = D';N = N';
D = exp( - D ./ avg_dist);
ak =  zeros(size(K_train));
for i=1:size(Y,1)
        ak(i,N(i,1:kc1)) = D(i,1:kc1);
end
ak = sparse(ak);

%% Tag completion from noisy tags
ratio = [0 0.1 0.2 0.3 0.5 0.7 0.9];% noise percentage
L01 = [ 2, 4, 5, 3, 4, 2, 1];%convergence rate/step size
epsilon = [1.2, 1.5, 1.5, 1.5, 1.5, 2, 2];
delta1 = [0.9, 0.85, 0.8, 0.75, 0.5, 0.41, 0.31]; %parameter for combining KNN results

alpha = [2.5, 3, 5, 5, 10, 120, 40];
beta = [1.2, 1.2, 1.5, 1.5, 0.5, 0.4, 1.2];
L02 = [2, 2, 6, 12, 12, 18, 1.5];
delta2 = [0.975,0.9, 0.9, 0.8, 0.53, 0.79, 0.94];
result_name = 'iap_noise.mat';% path of the finally saved file

%load(result_name);
for run = 1:runs
    % randomly sample "num_tag" tags for each image as observed tags, and
    % all the other tags are considered as unobserved ones
    Y_sample0 = single(full(Y));
    for i=1:size(Y,1)
        if sum(Y(i,:))>num_tag
            index = find( Y(i,:)==1 );

            list = randperm(length(index));
            Y_sample0(i,index(list(1:(length(index)-num_tag)))) = 0;
        end
    end
    
    for iter = 1:length(ratio)
        % create the noisy tag matrix
        % 1. switch certain percentage ("ratio") of initially observed tags
        % off ( 1 -> 0)
        % 2. switch the same number of initially unobserved tags on ( 0->1)
        % for each image
        Pos = rand(size(Y,1),num_tag)<=ratio(iter);
        [idy, ~] = find(Y_sample0'==1);
        idy = reshape(idy, num_tag, size(Y,1) )';
        Y_sample = zeros(size(Y));
        for i=1:size(Y,1)
            indexn = find( Pos(i,:)==1 );
            index = find( Y(i,:)==0 );
            list = randperm(length(index));
            idy(i,indexn) = index(list(1:length(indexn)));
            Y_sample(i,idy(i,:)) = 1;
        end
        
        % the matrix containing tags involving in the tag completion
        % process. The tags in this matrix will be excluded from the
        % evaluation.
        % The tags used for the evaluation: Y-Y_sample1
        % The manually labeled tags can also be used as evaluation tags. (Z in NUS-WIDE)
        Y_sample1 = Y_sample0|Y_sample;
        
        %================== KNN Feature ==========================
        % prepared for the linear combination of results coming from tag
        % completion and KNN voting
        W_knn = zeros(size(Y_sample));
        for i=1:kc
            W_knn = W_knn + Y_sample(N(:,i),:);
        end
        W_knn = bsxfun(@times, W_knn, 1./sum(W_knn,2));
  
 %%       %================== EGA ==========================
        % without considering visual feature
        [W,~,~,time] = EGA2(L01(iter), epsilon(iter), gamma, Y_sample);
        [p,r,c] = rank_eval_mc(W, Y, Y_sample1, 10);    
        load(result_name);
        result{run}{iter}(1,1:31) = [p', r', c', time];
        save(result_name, 'result');

        % KNN voting
        W_trmc = W - min(W(:));
        W_trmc = bsxfun(@times, W_trmc, 1./sum(W_trmc,2));
        Omega = delta1(iter)*10*W_trmc + (1-delta1(iter))*W_knn;
%         Omega = delta*10*W_trmc + (1-delta)*W_knn;rank_eval_mc(Omega, Y, Y_sample1, 
        [p,r,c] = rank_eval_mc(Omega, Y, Y_sample1, 10);
        load(result_name);
        result{run}{iter}(2,1:31) = [p', r', c', time];
        save(result_name, 'result');

        %================== EGAF ==========================
%%  % the method proposed in ECCV'14 paper, incorporating visual
        % features and irrelevant tag relations
        [P,~,~,time] = EGA2F(L02(iter), gamma, Y_sample, ak, alpha(iter), beta(iter));
%%
        [p,r,c] = rank_eval_mc(P, Y, Y_sample1, 10);   
        load(result_name);
        result{run}{iter}(3,1:31) = [p', r', c', time];
        save(result_name, 'result');
        
        % use the manually labeled tags Z for evaluation
        [p,r,c] = rank_eval(P, Z, max_rank); 
        load(result_name);
        result{run}{iter}(5,1:31) = [p', r', c', time];
        save(result_name, 'result');

        % further incorporating KNN voting results
        W_trmc = P - min(P(:));
        W_trmc = bsxfun(@times, W_trmc, 1./sum(W_trmc,2));
        Omega = delta2(iter)*10*W_trmc + (1-delta2(iter))*W_knn;
%         Omega = delta*10*W_trmc + (1-delta)*W_knn;rank_eval_mc(Omega, Y, Y_sample1,1)
        [p,r,c] = rank_eval_mc(Omega, Y, Y_sample1, 10);  
        load(result_name);
        result{run}{iter}(4,1:31) = [p', r', c', time];
        save(result_name, 'result');

    end
end




%% Tag completion from partially observed tags
obs_tag = [1 2 3 4 5]; %number of partially observed tags for each image
gamma = 1.02;
L01 = [ 2, 1, 2, 3, 3];
epsilon = [1, 8, 3, 2, 1.2];
delta1 = [0.6, 0.9, 0.85, 0.94, 0.9];

alpha = [3, 4, 3, 3.5, 3];
beta = [1.2,1.2, 1.2, 1.2, 1];
L02 = [1, 1, 0.8, 0.8, 1];
delta2 = [0.75,0.95,0.92, 0.97, 0.98];

result_name = 'iap_pobserv.mat';

for run = 1:runs
    % create the initially observed tags
    Y_sample0 = single(full(Y));
    for i=1:size(Y,1)
        if sum(Y(i,:))>num_tag
            index = find( Y(i,:)==1 );

            list = randperm(length(index), length(index)-num_tag);
            Y_sample0(i,index(list)) = 0;
        end
    end
    
    for iter = 1:length(obs_tag)
    % create the partially observed tags based on the initally observed tag
    % matrix
    Y_sample = single(full(Y_sample0));
    for i=1:size(Y_sample0,1)
        if sum(Y_sample0(i,:))>obs_tag(iter)
            index = find( Y_sample0(i,:)==1 );

            list = randperm(length(index), length(index)-obs_tag(iter));
            Y_sample(i,index(list)) = 0;
        end
    end
    
        %================== KNN Feature ==========================
        W_knn = zeros(size(Y_sample));
        for i=1:kc
            W_knn = W_knn + Y_sample(N(:,i),:);
        end
        W_knn = bsxfun(@times, W_knn, 1./sum(W_knn,2));
  
 %%       %================== EGA ==========================
        [W,~,~,time] = EGA2(L01(iter), epsilon(iter), gamma, Y_sample);
        [p,r,c] = rank_eval_mc(W, Y, Y_sample0, 10);    
        load(result_name);
        result2{run}{iter}(1,1:31) = [p', r', c', time];
        save(result_name, 'result2');

        W_trmc = W - min(W(:));
        W_trmc = bsxfun(@times, W_trmc, 1./sum(W_trmc,2));
        Omega = delta1(iter)*10*W_trmc + (1-delta1(iter))*W_knn;
%         Omega = delta*10*W_trmc + (1-delta)*W_knn;rank_eval_mc(Omega, Y, Y_sample0,1)
        [p,r,c] = rank_eval_mc(Omega, Y, Y_sample0, 10);
        load(result_name);
        result2{run}{iter}(2,1:31) = [p', r', c', time];
        save(result_name, 'result2');

        %================== EGAF ==========================
  %% Method proposed in ECCV'14
        [P,~,~,time] = EGA2F(L02(iter), gamma, Y_sample, ak, alpha(iter), beta(iter));
%%
        [p,r,c] = rank_eval_mc(P, Y, Y_sample0, 10);   
        load(result_name);
        result2{run}{iter}(3,1:31) = [p', r', c', time];
        save(result_name, 'result2');
        
        % use the manually labeled tags Z for evaluation
        [p,r,c] = rank_eval(P, Z, max_rank); 
        load(result_name);
        result2{run}{iter}(5,1:31) = [p', r', c', time];
        save(result_name, 'result2');
        

        W_trmc = P - min(P(:));
        W_trmc = bsxfun(@times, W_trmc, 1./sum(W_trmc,2));
        Omega = delta2(iter)*10*W_trmc + (1-delta2(iter))*W_knn;
%         Omega = delta*10*W_trmc + (1-delta)*W_knn;rank_eval_mc(Omega, Y, Y_sample0,1)
        [p,r,c] = rank_eval_mc(Omega, Y, Y_sample0, 10);  
        load(result_name);
        result2{run}{iter}(4,1:31) = [p', r', c', time];
        save(result_name,'result2');
    end
end

%%
matlabpool close