function P_list = eval_mc_list(W, Y, Y_sample, max_rank)

[num, tags] = size(Y);
W_res = W;
W_res( Y_sample>0) = 0;
[p_mat, tag_mat] = sort(W_res, 2, 'descend');
tag_mat = double( tag_mat );

M = sparse(num, tags);
prec_list = zeros(max_rank, 1);
rec_list = zeros(max_rank, 1);
coverage = zeros(max_rank, 1);
for rank = 1:max_rank
    M = M + sparse((1:num)', tag_mat(:, rank), ones(num, 1), num, tags) .* double((Y-Y_sample));
end

P_list = sum(M,2)/max_rank;