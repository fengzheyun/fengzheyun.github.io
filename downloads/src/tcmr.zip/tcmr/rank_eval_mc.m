function [prec_list, rec_list, coverage] = rank_eval_mc(W, Y, Y_sample, max_rank)
% Input:
%   T_P: predicted tags
%   T_C: assigned tags
%   max_rank: maximum rank
% Output:
%   prec_list: precision list over the rank
%   rec_list: recall list over the rank
[num, tags] = size(Y);
W_res = W;
W_res( Y_sample>0) = min(W(:));
[p_mat, tag_mat] = sort(W_res, 2, 'descend');
tag_mat = double( tag_mat );

M = sparse(num, tags);
prec_list = zeros(max_rank, 1);
rec_list = zeros(max_rank, 1);
coverage = zeros(max_rank, 1);
for rank = 1:max_rank
    M = M + sparse((1:num)', tag_mat(:, rank), ones(num, 1), num, tags) .* double(Y&(~Y_sample));
    prec_list(rank) = sum(sum(M)) ./ (rank * num);
    rec_list(rank) = mean(sum(M, 2) ./ double(sum(Y&(~Y_sample),2)));
    coverage(rank) = sum(sum(M,2)>0) ./ num;
end

end

