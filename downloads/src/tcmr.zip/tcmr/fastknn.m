function [D, N] = fastknn(X, k)
% [distance, index] = knn(query, data, k);
% Written by Mo Chen (mochen@ie.cuhk.edu.hk). Oct. 2010.

% [D, N] = sort(bsxfun(@plus,(-2)*(Y'*X),dot(Y,Y,1)'));
% N = N(1:k,:);
% D = D(1:k,:);

% top(x,k) is a partial sort function which returns top k entries of x
len_list = dot(X,X,2);
[D, N] = top(double(bsxfun(@plus,(-2)*(X*X'),len_list)), k+1);
% D = bsxfun(@plus,(-2)*Y,len_list);
% [D,N] = sort(D,1,'ascend');
D = D(2:k+1,:);
N = N(2:k+1,:);
D = bsxfun(@plus,D,len_list');
clear X;
D = D';
N = N';

