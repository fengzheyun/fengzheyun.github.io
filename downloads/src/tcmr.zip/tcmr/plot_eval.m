%% find optimal regularization term: epsilon
% epsilon = eps:1.2, mir: 1.2, iap:1.2, nus:3.5
% L0 = nus:6
temp = zeros(size(prec,1),length(epsilon));
for i=1:size(prec,1)
    if(i<8)
        temp(i,:) = prec{i}{1}(:,1)';
    else
        temp(i,2:end) = prec{i}{1}(:,1)';
    end
end
printMean = mean(temp,1);
printMean(1) = printMean(1)*size(prec,1)/7;

%% plot
printMean = zeros(17,30);
printDevi = zeros(17,30);
time = [];

for k = 1:17
    tempP = [];
    tempR = [];
    tempC = [];
    time = [];
    for i=1:11 
        if( size(result,2)<i)
            break;
        end
        if(isempty(result{i}) || size(result{i}{1},1)<k )
            continue;
        end
        if( result{i}{1}(k,1)==0 )
            continue;
        end
        tempP = [tempP; result{i}{1}(k,:)];
        tempR = [tempR; result{i}{2}(k,:)];
        tempC = [tempC; result{i}{3}(k,:)];
        
%         if ( i<11 )
%             time = [time; result{i}{4}(k) ];
%         end
    end
    if(isempty(tempP))
        continue;
    end
    printMean(k,1:10) = mean(tempP,1);
    printDevi(k,1:10) = std(tempP,0,1);
    printMean(k,11:20) = mean(tempR,1);
    printDevi(k,11:20) = std(tempR,0,1);
    printMean(k,21:30) = mean(tempR,1);
    printDevi(k,21:30) = std(tempR,0,1);
    
%     if(isempty(time))
%         printTime(k,1) = 0;
%         continue;
%     end
%     printTime(k,1) = mean(time, 1);
    
end
%
[j, s] = sort(prec(:,1),'descend');
s = s(1:5);
printMean = [printMean; mean(prec(s,1:30),1)];
printDevi = [printDevi; std(prec(s,1:30),0,1)];
[j, s] = sort(prec2(:,1),'descend');
s = s(1:5);
printMean = [printMean; mean(prec2(s,1:30),1)];
printDevi = [printDevi; std(prec2(s,1:30),0,1)];
[j, s] = sort(prec(:,1),'descend');
s = s(1:5);
printMean = [printMean; mean(precv(s,1:30),1)];
printDevi = [printDevi; std(precv(s,1:30),0,1)];
[j, s] = sort(prec2(:,1),'descend');
s = s(1:5);
printMean = [printMean; mean(precv2(s,1:30),1)];
printDevi = [printDevi; std(precv2(s,1:30),0,1)];

%% AP
figure,
handles = barweb(printMean([1:3,5,7,6,8,9,19],[1,2,4,6])',printDevi([1:3,5,7,6,8,9,19],[1,2,4,6])',...%content
    1,[1,2,4,6],[],'Top N completed tags','AP@N',jet,'y',...
    [{'LRES'},{'TMC'},{'MC-1'},{'FastTag'},{'LSR'},{'TagProp'},{'RKML'},{'vKNN'},{'TCMC'}]);
%%
figure,
handles = barweb(printMean([1:3,5,7,6,8,9,18],[1,2,4,6])',printDevi([1:3,5,7,6,8,9,18],[1,2,4,6])',...%content
    1,[1,2,4,6],[],'Top N completed tags','AP@N',jet,'y',...
    []);
%%
axis([0.5 4.5, 0,0.4])
%%
%% AR
figure,
handles = barweb(printMean([1:3,5,7,6,8,9,19],[11,12,14,16])',printDevi([1:3,5,7,6,8,9,19],[11,12,14,16])',...%content
    1,[1,2,4,6],[],'Top N completed tags','AR@N',jet,'y',...
    [{'LRES'},{'TMC'},{'MC-1'},{'FastTag'},{'LSR'},{'TagProp'},{'RKML'},{'vKNN'},{'TCMC'}]);
%%
figure,
handles = barweb(printMean([1:3,5,7,6,8,9,18],[11,12,14,16])',printDevi([1:3,5,7,6,8,9,18],[11,12,14,16])',...%content
    1,[1,2,4,6],[],'Top N completed tags','AR@N',jet,'y',...
    []);
%%
axis([0.5 4.5, 0,0.3])

%% C
figure,
handles = barweb(printMean([1:3,5,7,6,8,9,19],[21,22,24,26])',printDevi([1:3,5,7,6,8,9,19],[21,22,24,26])',...%content
    1,[1,2,4,6],[],'Top N completed tags','C@N',jet,'y',...
    [{'LRES'},{'TMC'},{'MC-1'},{'FastTag'},{'LSR'},{'TagProp'},{'RKML'},{'vKNN'},{'TCMC'}]);
%%
figure,
handles = barweb(printMean([1:3,5,7,6,8,9,19],[21,22,24,26])',printDevi([1:3,5,7,6,8,9,19],[21,22,24,26])',...%content
    1,[1,2,4,6],[],'Top N completed tags','C@N',jet,'y',...
    []);
%%
axis([0.5 4.5, 0,0.8])
%% Tag information:AP@N
figure,
handles = barweb(printMean([11:15,17,18],[1,2,4,6])',printDevi([11:15,17,18],[1,2,4,6])',...%content
    1,[1,2,4,6],[],'Top N completed tags',[],jet,'y',...
    [{'Freq'},{'LSA'},{'tKNN'},{'LDA'},{'LRES0'},{'pLSA'},{'TCMC0'}]);
%%
figure,
handles = barweb(printMean([11:15,17,18],[1,2,4,6])',printDevi([11:15,17,18],[1,2,4,6])',...%content
    1,[1,2,4,6],[],'Top N completed tags',[],jet,'y',...
    []);
%% Tag information:AR@N
figure,
handles = barweb(printMean([11:15,17,18],[11,12,14,16])',printDevi([11:15,17,18],[11,12,14,16])',...%content
    1,[1,2,4,6],[],'Top N completed tags',[],jet,'y',...
    [{'Freq'},{'LSA'},{'tKNN'},{'LDA'},{'LRES0'},{'pLSA'},{'TCMC0'}]);
%%
figure,
handles = barweb(printMean([11:15,17,18],[11,12,14,16])',printDevi([11:15,17,18],[11,12,14,16])',...%content
    1,[1,2,4,6],[],'Top N completed tags',[],jet,'y',...
    []);

%% Tag information:C@N
figure,
handles = barweb(printMean([11:15,17,18],[21,22,24,26])',printDevi([11:15,17,18],[21,22,24,26])',...%content
    1,[1,2,4,6],[],'Top N completed tags',[],jet,'y',...
    [{'Freq'},{'LSA'},{'tKNN'},{'LDA'},{'LRES0'},{'pLSA'},{'TCMC0'}]);
%%
figure,
handles = barweb(printMean([11:15,17,18],[21,22,24,26])',printDevi([11:15,17,18],[21,22,24,26])',...%content
    1,[1,2,4,6],[],'Top N completed tags',[],jet,'y',...
    []);




%% Partially observed tags
load hpcc/result_nips/iap_pobserv.mat;
obs_tag = [1 2 3 4 5];
% load hpcc/result_nips/nus_pobserv.mat;
% obs_tag = [1 2 3 4 6 8];
rank = 23;
for i=1:length(obs_tag) 
    for k = [1,3,5:7,9,12,13,17:20]
        temp = [];
        for j = 1:10
            temp = [temp; result2{j}{i}(k, rank)];
        end 
        printMean(k,i) = mean(temp,1);
        printDevi(k,i) = std(temp,0,1);
    end
end

%% AP
close all
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,19],:)',printDevi([1,3,5,7,6,9,12,13,19],:)',...%content
    1,obs_tag,[],'Number of observed tags','AP@3',jet,'y',...
    [{'LRES'},{'MC-1'},{'FastTag'},{'LSR'},{'TagProp'},{'vKNN'},{'LSA'},{'tKNN'},{'TCMC'}]);
%% Without legend
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,18],:)',printDevi([1,3,5,7,6,9,12,13,18],:)',...%content
    1,obs_tag,[],'Number of observed tags','AP@3',jet,'y',...
    []);

%% AR
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,18],:)',printDevi([1,3,5,7,6,9,12,13,19],:)',...%content
    1,obs_tag,[],'Number of observed tags','AR@5',jet,'y',...
    [{'LRES'},{'MC-1'},{'FastTag'},{'LSR'},{'TagProp'},{'vKNN'},{'LSA'},{'tKNN'},{'TCMC'}]);
%% Without legend
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,18],:)',printDevi([1,3,5,7,6,9,12,13,18],:)',...%content
    1,obs_tag,[],'Number of observed tags','AR@5',jet,'y',...
    []);
%% C
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,18],:)',printDevi([1,3,5,7,6,9,12,13,18],:)',...%content
    1,obs_tag,[],'Number of observed tags','C@3',jet,'y',...
    [{'LRES'},{'MC-1'},{'FastTag'},{'LSR'},{'TagProp'},{'vKNN'},{'LSA'},{'tKNN'},{'TCMC'}]);
%% Without legend
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,19],:)',printDevi([1,3,5,7,6,9,12,13,19],:)',...%content
    1,obs_tag,[],'Number of observed tags','C@3',jet,'y',...
    []);
%%
axis([0.5 6.5, 0,0.42])












%% Noisy tags
% load hpcc/result_nips/iap_noise.mat;
load hpcc/result_nips/nus_noise.mat;
ratio = [0 0.1 0.2 0.3 0.5 0.7 0.9];
rank = 13;
for i=1:length(ratio) 
    for k = [1,3,5:7,9,12,13,17:20]
        temp = [];
        for j = 1:10
            temp = [temp; result3{j}{i}(k, rank)];
        end 
        printMean(k,i) = mean(temp,1);
        printDevi(k,i) = std(temp,0,1);
    end
end

%% AP
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,19],:)',printDevi([1,3,5,7,6,9,12,13,19],:)',...%content
    1,ratio,[],'Noise percentage','AR@3',jet,'y',...
    [{'LRES'},{'MC-1'},{'FastTag'},{'LSR'},{'TagProp'},{'vKNN'},{'LSA'},{'tKNN'},{'TCMC'}]);
%% Without legend
figure,
handles = barweb(printMean([1,3,5,7,6,9,12,13,19],:)',printDevi([1,3,5,7,6,9,12,13,19],:)',...%content
    1,ratio,[],'Noise percentage','AP@10',jet,'y',...
    []);
%%
axis([0.5 7.5, 0,0.24])