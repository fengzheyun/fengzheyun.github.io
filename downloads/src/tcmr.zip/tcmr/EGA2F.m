function [W,L,obj_val, time] = EGA2F(L0, gamma, Y, S, alpha, beta)

% L0: initialized step size
% gamma: multiplicative factor gamma>1, making step size increase
% W0: initialized W

% http://www.machinelearning.org/archive/icml2009/papers/151.pdf
t = cputime;
L = L0;
k = 0;

S = sparse(S);
Y = double(Y);

Lap = diag(sum(S,2))-S;
W = 0.5*ones(size(Y));%Y/m_star;
floss = ObjectivefVal(Y, W, Lap, alpha);
F_obj_old = floss + beta*traceNorm(W);
obj_val = F_obj_old;

while 1
    gradientW = gradient( Y, W, Lap, alpha );
    C = W - 1/L * gradientW;
    [U, Sigma, V ] = svd_ed(C);
    fVal_old = floss;
    while 1         
        [pLW, traceNorm_pLW] = solution_p(U, Sigma, V, beta/L );                
        floss = ObjectivefVal(Y, pLW, Lap, alpha);
        PVal = fVal_old + PMid2Terms( pLW, W, gradientW, L );
        
        if floss <= PVal
            break;
        end
        L = gamma * L;
        fprintf('%d: f_obj = %.1f, P_obj = %.1f. TraceN = %.1f, L = %.2f\n', k, floss, PVal, traceNorm_pLW, L);
    end
    
    k = k+1;
    W = pLW;
    
    F_obj = floss + beta*traceNorm_pLW;
    
    if F_obj_old-F_obj < 1e-8 || k>5000
        break;
    end
    F_obj_old = F_obj;
%     obj_val = [obj_val;F_obj];
    fprintf('%d: total = %.4f, f_obj = %.1f, TraceN = %.1f, L = %.2f\n', k, F_obj, floss, traceNorm_pLW, L);
end

time = cputime-t;
end


function Delta = gradient( Y, W, Lap, alpha)

m_star = sum( Y(1,:)>0 );
m_comp = size(Y,2) - m_star;

W_temp = W;
W_temp(W==0) = 1e-8;
Delta = - (Y ./ W_temp )/m_star;

W_temp = 1 - W;
W_temp(W_temp==0) = 1e-8;
Delta = Delta + ( (1-Y) ./ W_temp )/m_comp;

Delta = Delta + 2*alpha/size(Y,1)*Lap*W;
end

function [T_C, nuclearNorm] = solution_p(U, Sigma, V, lambda)

Sigma = Sigma-lambda;
idx = (Sigma > 0);
T_C = U(:,idx) * diag(Sigma(idx)) * V(:,idx)';

nuclearNorm = sum( Sigma(idx) );

% T_C = max( 1e-8, T_C ); 
% T_C = bsxfun(@times, T_C, 1./sum(T_C,1));
end

function sum_obj = PMid2Terms( W, W_k_1, gradient, L )   
    dotProduct = trace((W-W_k_1)'*gradient);   
    Fnorm = L/2*sum( sum((W-W_k_1).^2,2),1);    
    sum_obj = dotProduct + Fnorm;
end


function value = ObjectivefVal(Y, W, Lap, alpha)
    m_star = sum(Y(1,:));
    m_comp = size(Y,2) - m_star;
    
    W_temp = W;
    W_temp(W<=0) = 1e-64;
    val = - Y.*log(W_temp)./m_star;
    
    W_temp = 1 - W;
    W_temp(W_temp<=0) = 1e-8;
    val = val - (1-Y).*log(W_temp)./m_comp;
    
    value = sum(sum(val,2),1) + alpha/size(Y,1)*trace(W'*Lap*W);
end


function traceP = traceNorm(P)
    if size(P,1)>size(P,2)
        S = eig(P'*P);
    else
        S = eig(P*P');
    end
    % S = diag(S);
    traceP = sum(sqrt(S(S>1e-8)));
end