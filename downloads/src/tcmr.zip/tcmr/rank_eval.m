function [prec_list, rec_list, coverage] = rank_eval(T_P, T_C, max_rank)
% Input:
%   T_P: predicted tags
%   T_C: assigned tags
%   max_rank: maximum rank
% Output:
%   prec_list: precision list over the rank
%   rec_list: recall list over the rank
T_C = double( T_C);
num_test_imgs = size(T_C, 1);
[p_mat, tag_mat] = sort(T_P, 2, 'descend');
tag_mat = double(tag_mat);
M = sparse(size(T_C, 1), size(T_C, 2));
prec_list = zeros(max_rank, 1);
rec_list = zeros(max_rank, 1);
coverage = zeros(max_rank, 1);
for rank = 1:max_rank
    M = M + sparse((1:num_test_imgs)', tag_mat(:, rank), ones(num_test_imgs, 1), num_test_imgs, size(T_C, 2)) .* T_C;
    prec_list(rank) = sum(sum(M)) ./ (rank * num_test_imgs);
    %pop_prec_list(rank) = pop_prec_list(rank) + sum(sum(T_C(:, 1:rank))) ./ (rank * num_test_imgs);
    rec_list(rank) = mean(sum(M, 2) ./ sum(T_C, 2));
    %pop_rec_list(rank) = pop_rec_list(rank) + mean(sum(T_C(:, 1:rank), 2) ./ sum(T_C, 2));
    coverage(rank) = sum(sum(M,2)>0) ./ num_test_imgs;
end

end

