function [U, Sigma, V ] = svd_ed( X )
% X: n * m, SVD for large matrix, where n >> m or m >> n
% Sigma: a vector contains all singular values

n = size(X,1);
% if m > n
%     X = X';
% end

if ( n<20000 )
    [U, Sigma, V ] = svd(X, 'econ');
    Sigma = diag(Sigma);
else
    [V, D] = eig( X' * X );
    S = sqrt(diag(D));
    U = X*V*diag(1./S);
    Sigma = S;
end

% if m > n
%     U_temp = U;
%     U = V;
%     V = U_temp;
% end

end