% clear;
addpath('vectools_matlab.tar');
addpath('methods');
addpath('funtools');
dataset = 'iaprtc12'; %'espgame''iaprtc12''flickr1m'
%-----------------------------------------
% Parameters
%-----------------------------------------
num_tags = 1000;                      % the most popular tags that will be used in study
train_per = 0.9;                    % percentage of data used for training
max_rank = 10;                      % maximum rank used in evaluation
num_neighbors = 100;
num_samples = 5000;
num_iter = 10;
width = 0.32;                        % kernel width-------------
smooth = 0.12;   
num_samples_avgdist = 10000;
output_file = sprintf('final_%s.mat', dataset);

for iter = 2
[X_train,Y_train,X_test,Y_test]  = LoadinDataSet( dataset, num_tags, train_per );

%--------------------------------------
% Compute the average distance
%--------------------------------------
img_list = randperm(size(X_train,1));
img_list = img_list(1:num_samples_avgdist);
A = X_train(img_list, :);
a_list = sum(A .^ 2, 2);
A = repmat(a_list, 1, num_samples_avgdist) + repmat(a_list', num_samples_avgdist, 1) - 2 .* A * A';
avg_dist = sum(sum(A)) / (num_samples_avgdist * (num_samples_avgdist - 1));
option.avg_dist_square = avg_dist;

%% Original Version
len = dot(X_train,X_train,2);
K_test = bsxfun(@plus,(-2)*(X_test*X_train'),dot(X_test,X_test,2));
K_test = bsxfun(@plus,K_test,len');
K_train = bsxfun(@plus,(-2)*(X_train*X_train'),len);
K_train = bsxfun(@plus,K_train,len');

K_train = exp( - K_train ./ (width .* option.avg_dist_square));
K_test = exp( - K_test ./ (width .* option.avg_dist_square));

tbegin = cputime;
num_tag = 291;%espgame 268
p = bsxfun(@rdivide,single(Y_train(:,1:num_tag)),sum(Y_train(:,1:num_tag),1));
g = p; g(g==0) = 1;
g = 1+sum(p.*log(g)./log(size(Y_train(:,1:num_tag),1)),1);
A = bsxfun(@times,g,log(single(Y_train(:,1:num_tag))+1));
[T,S,D] = svd(A,'econ');
t0 = cputime - tbegin;

tbegin = cputime;
% [UK,SK,VK] = largeSVD(K_train);
[UK,SK,VK] = svd(K_train,'econ');
SK = diag(SK);

rank_r = 5;
eigval_list = SK(1:end-rank_r).^2 + smooth;%option.smooth_param;

rank_y = 110; %espgame: 100; ipartc12: 110
T_lsi = bsxfun(@rdivide,T(:,1:rank_y),sqrt(sum(T(:,1:rank_y).^2,2)));
Kernel = VK(:,1:end-rank_r) * (diag(1 ./ sqrt(eigval_list)) * (UK(:,1:end-rank_r)'*T_lsi)); 
t1 = cputime - tbegin;

ak = K_test * Kernel * (K_train*Kernel)';
num = 1000;
[junk, indb] = top(double(-ak'),num);% top element in each column
num = 800; %espgame num = 1200; iaprtc12:800
j = reshape(indb(1:num,:),num*size(Y_test,1),1);
i = reshape(ones(num,1)*(1:size(Y_test,1)),num*size(Y_test,1),1);
s = reshape(-junk(1:num,:),num*size(Y_test,1),1);
sim = sparse(i,j,double(s),size(Y_test,1),size(Y_train,1));
T_P_Metric = sim*double(Y_train);
[prec2, rec2] = rank_eval(T_P_Metric, Y_test, max_rank);prec2(1)

num = 600; %espgame num = 500; iaprtc12: 600
T_P_Metric = Popularity( Y_train, num, indb);
[prec1, rec1] = rank_eval(T_P_Metric, Y_test, max_rank);prec1(1)

load( output_file );
result1{iter}(18,:) = [prec1', rec1',t1+t0];
result2{iter}(18,:) = [prec2', rec2',t1+t0];
save(output_file, 'result2','result1');

%% Low rank
tbegin = cputime;
sample_list = randperm(size(K_train,1),num_samples);
[UK,SK,VK] = svd(K_train(:,sample_list),'econ');
SK = diag(SK);

K_sample = K_train(sample_list,sample_list);
eigval = SK.^2 + smooth;%option.smooth_param;
L = UK * (diag(1./sqrt(eigval))*VK'*K_sample*VK*diag(1./sqrt(eigval))* (UK'*T_lsi)); 
t1 = cputime-tbegin;

ak = K_test * L * (K_train*L)';
num = 3000;
[junk, indb] = top(double(-ak'),num);% top element in each column
num = 800; %espgame num = 800; iaprtc12: 800
j = reshape(indb(1:num,:),num*size(Y_test,1),1);
i = reshape(ones(num,1)*(1:size(Y_test,1)),num*size(Y_test,1),1);
s = reshape(-junk(1:num,:),num*size(Y_test,1),1);
sim = sparse(i,j,double(s),size(Y_test,1),size(Y_train,1));
T_P_Metric = sim*double(Y_train);
[prec2, rec2] = rank_eval(T_P_Metric, Y_test, max_rank);

num = 300; %espgame num = 500; iaprtc12: 300
T_P_Metric = Popularity( Y_train, num, indb);
[prec1, rec1] = rank_eval(T_P_Metric, Y_test, max_rank);
load( output_file );
result1{iter}(19,:) = [prec1', rec1',t1+t0];
result2{iter}(19,:) = [prec2', rec2',t1+t0];
save(output_file, 'result2','result1');

clear X_train X_test K_train K_test T*
end
